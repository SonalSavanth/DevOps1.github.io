WATER AND ELECTRICITY CONSUMPTION TRACKING WEBSITE



Prototype : A website that tracks and manages electricity and water consumption.


In this modern society where everyone are leading a busy life, it's very important to conserve resources and save money.So with our intuitive platform the users can easily track their

 
electricity and water usage, identify trends and are able to make informed decisions to conserve resources and save money.


So this is an all-in-one solution for monitoring and managing water and electricity consumption in your household.





KEY FEATURES OF THIS WEBSITE : 




With the help of this webiste, users are able to track their daily, monthly and yearly consumption of water and electricity.



With the help of this website, users are able to get an idea for both water and electricity consumption.



If the usage is beyond the limit, then the users will get a pop up notification regarding this.



Users are able to analyze water flow and power socket electricity usage individually. There will a sensor ( flow sensor ) to detect water usage from individual taps.



There will be a bill calculator and if the electricity and water bill are not paid on time , it will continuously send notifications. So the users will be able to pay both the bills on time.






BACKGROUND OF THE PROJECT 



"Water and electricity consumption tracking website" starts with the need of users who are not aware of how much water and electricty they are using on daily basis.


The project team thought about one of the most important problem faced by today's society in this busy world and they thought about making website which will help the people to analyze the


consumption of two most important things in their life which is inevitable.



CONCEPTS USED: 


In the making of this project we have used conceptual learnings to improvise it. 


The concepts used are: 


1) HTML 5 

2) CSS 

3) External CSS 

4) Internal CSS 

5) Javascript





